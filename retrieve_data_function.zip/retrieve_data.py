import json
import boto3

dynamodb = boto3.resource('dynamodb')

table = dynamodb.Table('MyDataTable')

def lambda_handler(event, context):
    item_id = event['pathParameters']['id']
    response = table.get_item(Key={'id': item_id})
    item = response.get('Item')
    
    if item:
        # Return a response with a status code of 200 and the item in the body
        return {
            'statusCode': 200,         
            'body': json.dumps(item)    # Convert the item dictionary to a JSON string
        }
    else:
        # Return a response with a status code of 404 if the item was not found
        return {
            'statusCode': 404,                  
            'body': json.dumps({'error': 'Item not found'})  # Return an error message
        }
